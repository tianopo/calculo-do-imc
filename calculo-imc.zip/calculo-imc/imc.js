
var botao = document.querySelector('#botao');

botao.addEventListener("click",function(event){
    event.preventDefault(event);

    var form = document.querySelector(".container");
    var pessoa = criarValores(form);
    var linha = montaTr(pessoa);

    var tabela = document.querySelector("#tabela");

    tabela.appendChild(linha);
    
    form.reset();
})

function criarValores(form){
    
    var pessoa = {
        nome: form.nome.value,
        peso: form.peso.value,
        altura: form.altura.value,
        imc: form.peso.value/(form.altura.value * form.altura.value)
    }
    return pessoa; 
}

function montaTr(pessoa){

    var linha = document.createElement("tr");
    linha.classList.add('principal');

    var nomeTd = montaTd(pessoa.nome,"info-nome");
    var pesoTd = montaTd(pessoa.peso,"info-peso");
    var alturaTd = montaTd(pessoa.altura,"info-altura");
    var imcTd = montaTd(pessoa.imc.toFixed(2    ),"info-imc");

    linha.appendChild(nomeTd);
    linha.appendChild(pesoTd);
    linha.appendChild(alturaTd);
    linha.appendChild(imcTd);

    return linha;
}

function montaTd(dado,classe){
    var td = document.createElement("td");
    td.textContent = dado;
    td.classList.add(classe);
    return td;
}
        
