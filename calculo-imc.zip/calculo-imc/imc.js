
        var botao = document.querySelector('#botao');

        botao.addEventListener("click",function(event){
            event.preventDefault();
            
            var form = document.querySelector(".container");

            var nome = form.nome.value;
            var peso = form.peso.value;
            var altura = form.altura.value;
            var imc = peso / (altura * altura)

            var nomeTd = document.createElement("td")
            var pesoTd = document.createElement("td")
            var alturaTd = document.createElement("td")
            var imcTd = document.createElement('td')

            nomeTd.textContent = nome;
            pesoTd.textContent = peso;
            alturaTd.textContent = altura;
            imcTd.textContent = imc.toFixed(2);

            var pessoa = document.createElement("tr");
            
            pessoa.appendChild(nomeTd);
            pessoa.appendChild(pesoTd);
            pessoa.appendChild(alturaTd);
            pessoa.appendChild(imcTd);

            var tabela = document.querySelector("#tabela");

            tabela.appendChild(pessoa);
        })
